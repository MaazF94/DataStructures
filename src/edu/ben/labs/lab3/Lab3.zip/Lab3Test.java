package edu.ben.labs.lab3;

import static org.junit.Assert.*;

import org.junit.Test;

public class Lab3Test {

	@Test
	public void testTakeOrder() {

		// testing null case
		CoffeeHouse c = new CoffeeHouse();
		assertEquals(false, c.takeOrder(null));

		// test with one order
		Coffee order1 = new Coffee("Chocolate", 2, 2.00, 30);

		assertEquals(true, c.takeOrder(order1));

		// test with an empty order
		Coffee emptyOrder = new Coffee("", 0, 0, 0);

		assertEquals(true, c.takeOrder(emptyOrder));

	}

	@Test
	public void testServeOrder() {

		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 2, 2.00, 30);
		assertEquals(true, c.takeOrder(order1));

		assertEquals(order1, c.serveOrder());
	}

	@Test
	public void testGetPotentialProfit() {

		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 2, 2.00, 30);
		Coffee order2 = new Coffee("Chocolate", 3, 4.33, 30);
		Coffee order3 = new Coffee("Chocolate", 2, 2.16, 30);

		c.takeOrder(order1);
		c.takeOrder(order2);
		c.takeOrder(order3);

		double expected = 8.49;
		double actual = c.getPotentialProfit();
		assertEquals(expected, actual, 0);

	}

	@Test
	public void testTimeToMakeCoffeeOrders() {
		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 2, 2.00, 30);
		Coffee order2 = new Coffee("Mocha", 3, 4.00, 30);
		Coffee order3 = new Coffee("Vanilla", 2, 2.00, 30);

		int expected = 0;
		int actual = c.timeToMakeCoffeeOrders();
		assertEquals(expected, actual);

		c.takeOrder(order1);
		c.takeOrder(order2);
		c.takeOrder(order3);

		int expected1 = 90;
		int actual1 = c.timeToMakeCoffeeOrders();
		assertEquals(expected1, actual1);
	}

	@Test
	public void testNumOfOrders() {

		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 2, 2.00, 30);

		c.takeOrder(order1);

		int expected = 1;
		int actual = c.numOfOrders();
		assertEquals(expected, actual);

		int expected1 = 1;
		int actual1 = c.getNumOrders();
		assertEquals(expected1, actual1);
	}

	@Test
	public void testGetSizeCount() {

		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 1, 2.00, 30);
		Coffee order2 = new Coffee("Chocolate", 1, 2.00, 30);
		Coffee order3 = new Coffee("Chocolate", 2, 2.00, 30);
		Coffee order4 = new Coffee("Chocolate", 3, 2.00, 30);
		
		

		c.takeOrder(order1);
		c.takeOrder(order2);
		c.takeOrder(order3);
		c.takeOrder(order4);

		int[] array = c.getSizeCount();

		int expected = 2;
		int actual = array[0];
		assertEquals(expected, actual);

		int expected1 = 1;
		int actual1 = array[1];
		assertEquals(expected1, actual1);

		int expected2 = 1;
		int actual2 = array[2];
		assertEquals(expected2, actual2);
	}

	@Test
	public void testViewNextOrder() {

		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 3, 4.00, 30);
		Coffee order2 = new Coffee("Chocolate", 2, 2.00, 30);

		c.takeOrder(order2);
		c.takeOrder(order1);
		Coffee expected = order2;
		Coffee actual = c.viewNextOrder();
		assertEquals(expected, actual);

		c.serveOrder();
		c.serveOrder();
		Coffee expected1 = null;
		Coffee actual1 = c.viewNextOrder();
		assertEquals(expected1, actual1);
	}

	@Test
	public void testGetProfit() {

		CoffeeHouse c = new CoffeeHouse();
		Coffee order1 = new Coffee("Chocolate", 3, 4.00, 30);
		Coffee order2 = new Coffee("Chocolate", 2, 2.00, 30);

		double expected = 0;
		double actual = c.getProfit();
		assertEquals(expected, actual, 0);

		c.takeOrder(order1);
		c.takeOrder(order2);
		c.serveOrder();
		c.serveOrder();

		double expected1 = 6.0;
		double actual1 = c.getProfit();
		assertEquals(expected1, actual1, 0);

	}
}
