package edu.ben.labs.lab6;

/**
 * 
 * @author maazfitter
 * @version 1.0
 * 
 */
public class InvalidInputType extends Exception { // extends exception

	/**
	 * class variable serial version
	 */
	private static final long serialVersionUID = -1125848588555368328L;

}
